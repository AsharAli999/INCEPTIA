import React from 'react'
import Sidebar from './components/Sidebar'

const App = () => {
  return (
    <div>
      <Sidebar/>
    </div>
  )
}

export default App